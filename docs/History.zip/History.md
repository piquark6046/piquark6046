## PiQuark6046's History
### AD 2020, 12020 HE
* Recorded as a Runner up by AdGuard. [#1](https://adguard.com/en/blog/best-contributors-2020.html)